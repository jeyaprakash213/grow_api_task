const mongoose = require("mongoose");
const url = "";

module.exports = mongoose.connect(url, (err) => {
    if (err) {
        throw err
    } else {
        console.log("db connected")
    }
})