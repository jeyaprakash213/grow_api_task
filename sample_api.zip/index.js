const express = require("express");
const app = express();
const User = require("./model");
const DB = require("./db");

app.get("/", async (req, res) => {
    res.send("hello")
})

app.post("/userRegistration", async (req, res) => {
    // const userData = await User.findOne({ email: req.body.email })
    // if (userData) {
    //     res.send({ massege: "user already excits" })
    // } else {
    // }

    if (req.body.email) {
        const Email = req.body.email
        const passward = req.body.passward
        const emailCheck = await Email.split("@")
        const emailpassward = await passward.length
        console.log("emailCheck", emailCheck, emailpassward)
        if (emailCheck[1] == "gmail.com" && emailpassward == "8") {
            const newUser = new User({
                name: req.body.name,
                email: req.body.email,
                passward: req.body.passward,
                data: req.body.data
            })

            const saveUser = await newUser.save()
            res.send({ massege: "user created successfully", data: saveUser })
        } else {
            res.send({ massege: "Email or password  not valid" })
        }
    }



})


app.listen("5678", (err) => {
    if (err) {
        throw err
    } else {
        console.log("server created ")
    }
})